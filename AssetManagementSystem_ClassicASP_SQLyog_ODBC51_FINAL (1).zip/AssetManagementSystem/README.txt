BEL IT ASSET MANAGEMENT SYSTEM
Classic ASP + IIS + ADO + MySQL ODBC 5.1 + SQLyog

============================================================
1. PROJECT STRUCTURE
============================================================
AssetManagementSystem\
    login.asp
    logout.asp
    index.asp
    asset_declaration.asp
    asset_report.asp
    asset_edit.asp
    asset_delete.asp
    schema_mysql.sql
    includes\db.asp
    includes\auth.asp
    wwwroot\css\style.css
    wwwroot\js\script.js

The backend is Classic ASP. SQLyog is used to create/manage the
MySQL database. IIS runs the ASP application. ADO connects to
MySQL through MySQL ODBC 5.1.

============================================================
2. DATABASE SETUP USING SQLyog
============================================================
1. Start MySQL Server.
2. Open SQLyog.
3. Connect to:
      Host: localhost
      Port: 3306
      User: root
      Password: your MySQL root password
4. Open:
      schema_mysql.sql
5. Execute the complete file.
6. It creates:
      AssetManagementDB
      users
      assets
7. Demo login:
      Staff ID: BEL001
      Password: 01011990

Login is always Staff ID + DOB password in DDMMYYYY format.

IMPORTANT:
The SQL script contains one sample asset. You can delete it from
SQLyog if you want the report to start empty.

============================================================
3. MYSQL ODBC 5.1
============================================================
This project is configured for:
      MySQL ODBC 5.1 Driver

The connection is in:
      includes\db.asp

Default connection:
      DRIVER={MySQL ODBC 5.1 Driver}
      SERVER=localhost
      PORT=3306
      DATABASE=AssetManagementDB
      USER=root
      PASSWORD=

If your MySQL root account has a password, open db.asp and change:
      PASSWORD=;
into your actual password.

If your installed driver is 32-bit, IIS must run the application
pool in 32-bit mode:

1. Open IIS Manager.
2. Click Application Pools.
3. Select the application pool used by this project.
4. Click Advanced Settings.
5. Set:
      Enable 32-Bit Applications = True
6. Click OK.
7. Restart IIS.

============================================================
4. ENABLE CLASSIC ASP IN WINDOWS
============================================================
1. Press Win + R.
2. Type:
      optionalfeatures
3. Press Enter.
4. Open:
      Internet Information Services
      -> World Wide Web Services
      -> Application Development Features
5. Tick:
      ASP
6. Click OK.

============================================================
5. PUT THE OLD ASSET FOLDER IN IIS
============================================================
Use the project folder exactly as:
      AssetManagementSystem

Recommended location:
      C:\inetpub\wwwroot\AssetManagementSystem

Do not put the project inside the Library folder.

============================================================
6. CONFIGURE IIS
============================================================
1. Press Win + R.
2. Type:
      inetmgr
3. Press Enter.
4. In IIS Manager, expand Sites -> Default Web Site.
5. Right-click Default Web Site.
6. Select Add Application.
7. Alias:
      AssetManagementSystem
8. Physical path:
      C:\inetpub\wwwroot\AssetManagementSystem
9. Click OK.

Select the new application and open ASP.
Set:
      Enable Parent Paths = True

If using a dedicated application pool, make sure the pool is started.

============================================================
7. OPEN THE APPLICATION
============================================================
Open:
      http://localhost/AssetManagementSystem/login.asp

Login with:
      Staff ID: BEL001
      Password: 01011990

Login is always Staff ID + DOB password in DDMMYYYY format.

============================================================
8. ASSET DECLARATION FIELDS
============================================================
Top:
- Staff ID (taken from the logged-in user)
- Cost Center

1. Location & System Information:
- Zone 1 to 12
- Location
- Host Name
- Serial No
- MAC Address
- IP Address
- Domain Name
- Operating System
- RAM (GB)
- Hard Disk (GB)
- Hard Disk Used (GB)

2. Asset Details:
- Asset Number
- Asset Type
- Make
- Model
- Year of Manufacture (manual 4-digit entry, for example 2024)
- Type of Network
- Asset Used By (Self / Others)
- Warranty

Asset Type is a nested dropdown:

Desktop PC
    -> High End
    -> Standard

Laptop
    -> High End
    -> Standard
    -> Medium

Workstation
    -> High
    -> Standard
    -> Medium

Other Asset Types
    -> Printer
    -> Scanner
    -> Server
    -> Other

============================================================
9. IMPORTANT DATABASE CONSTRAINTS
============================================================
- MAC Address is the PRIMARY KEY.
- Asset Number is UNIQUE.
- Serial Number is UNIQUE.
- Staff ID and Cost Center are indexed for report searching.
- Zone is restricted to 1-12.
- Operating System uses the configured list.
- Network Type is Intranet / Internet / Standalone.
- Asset Used By is Self / Others.
- RAM must be greater than 0.
- Hard Disk must be greater than 0.
- Hard Disk Used cannot be greater than Hard Disk.
- Year of Manufacture must be entered manually as a 4-digit year (1900-2100).

The ASP page also validates these rules before saving.

============================================================
10. ASSET REPORT
============================================================
The Asset Report has three independent search fields:
- Staff ID
- Cost Center
- MAC Address

Any one field can be used by itself. For example, you can enter another staff member's Staff ID and search their assets. You can also use two or all three fields together;
when multiple fields are filled, the results must match all supplied filters.

The report is a proper table with visible vertical and horizontal
column lines. It is not displayed as cards.

For each selected asset you can:
- Edit
- Delete

The report can also be exported to CSV. The CSV export keeps the
current Staff ID, Cost Center and MAC Address filters.

============================================================
11. EDITING AN ASSET
============================================================
Click Edit in the Asset Report.

All asset information can be corrected except MAC Address.
MAC Address remains read-only because it is the PRIMARY KEY.

After saving, return to Asset Report to see the updated values.

============================================================
12. IF DATABASE CONNECTION FAILS
============================================================
Check these in order:

1. MySQL Server is running.
2. SQLyog can connect to localhost:3306.
3. AssetManagementDB exists in SQLyog.
4. MySQL ODBC 5.1 Driver is installed.
5. The DRIVER name in includes\db.asp exactly matches the installed
   ODBC driver name.
6. The root password in db.asp is correct.
7. If ODBC 5.1 is 32-bit, IIS Application Pool has:
      Enable 32-Bit Applications = True
8. IIS ASP is enabled.
9. The IIS physical path points to:
      C:\inetpub\wwwroot\AssetManagementSystem

============================================================
13. FINAL ARCHITECTURE
============================================================
Browser
   |
   v
IIS
   |
   v
Classic ASP (.asp)
   |
   v
ADO
   |
   v
MySQL ODBC 5.1
   |
   v
MySQL Server
   ^
   |
SQLyog is used to create, inspect and manage the database.

No PHP, Flask, Node.js or Python is required for this project.
