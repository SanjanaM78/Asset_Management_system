<%@ Language="VBScript" CodePage="65001" %>
<%
Option Explicit
Response.Buffer = True
Response.CodePage = 65001
Response.CharSet = "UTF-8"
Session.CodePage = 65001

Dim conn, connStr, dbError
Set conn = Server.CreateObject("ADODB.Connection")

' ============================================================
' BEL IT Asset Management
' Classic ASP + ADO + MySQL ODBC 5.1 + SQLyog
' ============================================================
' IMPORTANT: This project is configured for MySQL ODBC 5.1.
' If your PC shows a different installed driver name, change ONLY
' the DRIVER value below.
' ============================================================

connStr = "DRIVER={MySQL ODBC 5.1 Driver};" & _
          "SERVER=localhost;" & _
          "PORT=3306;" & _
          "DATABASE=AssetManagementDB;" & _
          "USER=root;" & _
          "PASSWORD=;" & _
          "OPTION=3;"

On Error Resume Next
conn.Open connStr
dbError = Err.Description
On Error GoTo 0

If conn.State <> 1 Then
    Response.Write "<div style='font-family:Arial;padding:30px;color:#8b0000;'>"
    Response.Write "<h2>Database connection failed</h2>"
    Response.Write "<p>Check MySQL Server, the MySQL ODBC 5.1 Driver, database name, root password and includes/db.asp.</p>"
    Response.Write "<p><b>Error:</b> " & Server.HTMLEncode(dbError) & "</p>"
    Response.Write "</div>"
    Response.End
End If
%>
