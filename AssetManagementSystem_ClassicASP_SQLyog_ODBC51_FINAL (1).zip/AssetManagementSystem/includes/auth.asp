<%
If Trim(CStr(Session("staffId") & "")) = "" Then
    Response.Redirect "login.asp?msg=Please+login+to+continue"
    Response.End
End If
%>
