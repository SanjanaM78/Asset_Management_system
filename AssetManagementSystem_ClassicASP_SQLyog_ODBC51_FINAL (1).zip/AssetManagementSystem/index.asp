<%@ Language="VBScript" CodePage="65001" %>
<!--#include file="includes/auth.asp"-->
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>IT Asset Declaration</title>
<link rel="stylesheet" href="wwwroot/css/style.css">
</head>
<body>
<header class="site-header">
    <div>
        <h1>IT Asset Declaration</h1>
        <p>Enter the IT asset information used for the Asset Report.</p>
    </div>
    <div class="user-area">
        <span><%=Server.HTMLEncode(Session("staffId"))%></span>
        <a href="logout.asp">Logout</a>
    </div>
</header>
<nav class="main-nav">
    <a href="asset_report.asp">Asset Report</a>
    <a href="asset_declaration.asp">Asset Declaration</a>
</nav>

<main class="home-container">
    <h2>IT Asset Management</h2>
    <div class="home-links">
        <a href="asset_declaration.asp">Asset Declaration</a>
        <a href="asset_report.asp">Asset Report</a>
    </div>
</main>
</body>
</html>
