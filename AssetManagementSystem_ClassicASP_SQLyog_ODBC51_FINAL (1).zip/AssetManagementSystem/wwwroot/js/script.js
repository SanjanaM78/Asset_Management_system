(function () {
    "use strict";

    var assetGroups = [
        {
            label: "Desktop PC",
            values: ["Desktop PC - High End", "Desktop PC - Standard"]
        },
        {
            label: "Laptop",
            values: ["Laptop - High End", "Laptop - Standard", "Laptop - Medium"]
        },
        {
            label: "Workstation",
            values: ["Workstation - High", "Workstation - Standard", "Workstation - Medium"]
        },
        {
            label: "Other Asset Types",
            values: ["Printer", "Scanner", "Server", "Other"]
        }
    ];

    function normalizeMac(input) {
        if (!input || input.readOnly) return;
        input.value = input.value.replace(/-/g, ":").replace(/\s/g, "").toLowerCase();
    }

    function setupAssetTypeDropdown() {
        var select = document.getElementById("asset_type");
        if (!select || select.dataset.ready === "1") return;

        select.dataset.ready = "1";
        select.required = false;

        var wrapper = document.createElement("div");
        wrapper.className = "asset-type-picker";

        var button = document.createElement("button");
        button.type = "button";
        button.className = "asset-type-button";
        button.setAttribute("aria-expanded", "false");
        button.innerHTML = "<span>Select Asset Type</span><span class=\"picker-arrow\">▼</span>";

        var menu = document.createElement("div");
        menu.className = "asset-type-menu";

        function closeSubmenus() {
            var openMenus = menu.querySelectorAll(".asset-submenu.open");
            for (var i = 0; i < openMenus.length; i++) {
                openMenus[i].classList.remove("open");
            }
        }

        function displayValue(value) {
            var text = button.querySelector("span");
            if (text) text.textContent = value || "Select Asset Type";
        }

        assetGroups.forEach(function (group) {
            var item = document.createElement("div");
            item.className = "asset-type-item";

            var main = document.createElement("button");
            main.type = "button";
            main.className = "asset-type-main";
            main.innerHTML = "<span>" + group.label + "</span><span class=\"submenu-arrow\">›</span>";

            var submenu = document.createElement("div");
            submenu.className = "asset-submenu";

            group.values.forEach(function (value) {
                var option = document.createElement("button");
                option.type = "button";
                option.className = "asset-sub-option";
                option.textContent = value.replace(group.label + " - ", "");

                option.addEventListener("click", function (event) {
                    event.stopPropagation();
                    select.value = value;
                    displayValue(value);
                    menu.classList.remove("open");
                    button.setAttribute("aria-expanded", "false");
                    closeSubmenus();
                    select.dispatchEvent(new Event("change", { bubbles: true }));
                });

                submenu.appendChild(option);
            });

            main.addEventListener("click", function (event) {
                event.stopPropagation();
                var alreadyOpen = submenu.classList.contains("open");
                closeSubmenus();
                if (!alreadyOpen) submenu.classList.add("open");
            });

            item.appendChild(main);
            item.appendChild(submenu);
            menu.appendChild(item);
        });

        button.addEventListener("click", function (event) {
            event.stopPropagation();
            var open = menu.classList.toggle("open");
            button.setAttribute("aria-expanded", open ? "true" : "false");
            if (!open) closeSubmenus();
        });

        document.addEventListener("click", function () {
            menu.classList.remove("open");
            button.setAttribute("aria-expanded", "false");
            closeSubmenus();
        });

        select.parentNode.insertBefore(wrapper, select);
        wrapper.appendChild(button);
        wrapper.appendChild(menu);
        wrapper.appendChild(select);
        select.classList.add("real-asset-type-select");

        if (select.value) displayValue(select.value);
    }

    function validateMac() {
        var input = document.querySelector('input[name="mac_address"]');
        if (!input || input.value.trim() === "") return false;
        var pattern = /^([0-9a-f]{2}:){5}[0-9a-f]{2}$/i;
        return pattern.test(input.value.trim());
    }

    function validateAssetForm() {
        var form = document.getElementById("assetForm");
        if (!form) return true;

        var mac = document.querySelector('input[name="mac_address"]');
        if (mac) normalizeMac(mac);

        if (!validateMac()) {
            alert("Enter a valid MAC Address, for example AA:BB:CC:DD:EE:FF.");
            if (mac) mac.focus();
            return false;
        }

        var assetType = document.getElementById("asset_type");
        if (assetType && assetType.value === "") {
            alert("Please select an Asset Type.");
            return false;
        }

        var hardDisk = document.querySelector('input[name="hard_disk"]');
        var hardDiskUsed = document.querySelector('input[name="hard_disk_used"]');
        if (hardDisk && hardDiskUsed && hardDisk.value !== "" && hardDiskUsed.value !== "") {
            var total = parseFloat(hardDisk.value);
            var used = parseFloat(hardDiskUsed.value);
            if (!isNaN(total) && !isNaN(used) && used > total) {
                alert("Hard Disk Used cannot be greater than Hard Disk capacity.");
                hardDiskUsed.focus();
                return false;
            }
        }

        var year = document.querySelector('input[name="year_of_manufacture"]');
        if (year && year.value !== "") {
            var y = parseInt(year.value, 10);
            var maxYear = new Date().getFullYear() + 1;
            if (isNaN(y) || y < 1980 || y > maxYear) {
                alert("Enter a valid Year of Manufacture.");
                year.focus();
                return false;
            }
        }

        return true;
    }

    window.validateAssetForm = validateAssetForm;

    document.addEventListener("DOMContentLoaded", function () {
        setupAssetTypeDropdown();

        var mac = document.querySelector('input[name="mac_address"]');
        if (mac && !mac.readOnly) {
            mac.addEventListener("blur", function () {
                normalizeMac(mac);
            });
        }
    });
})();
