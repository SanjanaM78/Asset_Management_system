<%@ Language="VBScript" CodePage="65001" %>
<%
Option Explicit
Response.CodePage = 65001
Response.CharSet = "UTF-8"

Dim errorMessage, message, staffIdInput, passwordInput
errorMessage = ""
message = Trim(Request.QueryString("msg"))

If Trim(CStr(Session("staffId") & "")) <> "" Then
    Response.Redirect "index.asp"
    Response.End
End If

If Request.ServerVariables("REQUEST_METHOD") = "POST" Then
    staffIdInput = Trim(Request.Form("staff_id"))
    passwordInput = Trim(Request.Form("password"))

    If staffIdInput = "" Or passwordInput = "" Then
        errorMessage = "Please enter Staff ID and DOB password."
    Else
        %><!--#include file="includes/db.asp"--><%
        Dim cmd, rs, sql
        sql = "SELECT staff_id, full_name FROM users WHERE staff_id=? AND password_value=? AND is_active=1"

        Set cmd = Server.CreateObject("ADODB.Command")
        Set cmd.ActiveConnection = conn
        cmd.CommandText = sql
        cmd.CommandType = 1
        cmd.Parameters.Append cmd.CreateParameter("p1", 200, 1, 50, staffIdInput)
        cmd.Parameters.Append cmd.CreateParameter("p2", 200, 1, 50, passwordInput)

        Set rs = cmd.Execute

        If Not rs.EOF Then
            Session("staffId") = CStr(rs("staff_id"))
            Session("fullName") = CStr(rs("full_name"))
            rs.Close
            Set rs = Nothing
            Set cmd = Nothing
            conn.Close
            Set conn = Nothing
            Response.Redirect "index.asp"
            Response.End
        Else
            errorMessage = "Invalid Staff ID or DOB password."
        End If

        rs.Close
        Set rs = Nothing
        Set cmd = Nothing
        conn.Close
        Set conn = Nothing
    End If
End If
%>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>IT Asset Declaration - Login</title>
<link rel="stylesheet" href="wwwroot/css/style.css">
</head>
<body class="login-page">
<div class="login-box">
    <div class="login-header">
        <div class="company-mark">BEL</div>
        <h1>IT Asset Declaration</h1>
        <p>Staff Login</p>
    </div>

    <% If message <> "" Then %>
        <div class="alert success"><%=Server.HTMLEncode(message)%></div>
    <% End If %>
    <% If errorMessage <> "" Then %>
        <div class="alert error"><%=Server.HTMLEncode(errorMessage)%></div>
    <% End If %>

    <form method="post" action="login.asp">
        <label for="staff_id">Staff ID <span>*</span></label>
        <input id="staff_id" type="text" name="staff_id" maxlength="50" required autocomplete="username">

        <label for="password">DOB Password <span>*</span></label>
        <input id="password" type="password" name="password" maxlength="8" required autocomplete="current-password" placeholder="DDMMYYYY">
        <div class="field-note">Password format: DDMMYYYY</div>

        <button type="submit" class="btn primary full">Login</button>
    </form>
</div>
</body>
</html>
