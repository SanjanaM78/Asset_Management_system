-- ============================================================
-- BEL IT ASSET MANAGEMENT SYSTEM
-- Classic ASP + ADO + MySQL + MySQL ODBC 5.1 + SQLyog
-- ============================================================

CREATE DATABASE IF NOT EXISTS AssetManagementDB
CHARACTER SET utf8
COLLATE utf8_general_ci;

USE AssetManagementDB;

DROP TABLE IF EXISTS assets;
DROP TABLE IF EXISTS users;

-- ============================================================
-- USERS
-- Login password is DOB in DDMMYYYY format.
-- ============================================================
CREATE TABLE users (
    staff_id VARCHAR(50) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    password_value CHAR(8) NOT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (staff_id),
    CONSTRAINT chk_users_password CHECK (CHAR_LENGTH(password_value) = 8)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO users (staff_id, full_name, password_value, is_active)
VALUES
('BEL001', 'Demo Staff', '01011990', 1),
('BEL002', 'IT Staff', '02021990', 1);

-- ============================================================
-- ASSETS
-- MAC ADDRESS is the PRIMARY KEY.
-- ============================================================
CREATE TABLE assets (
    staff_id VARCHAR(50) NOT NULL,
    cost_center VARCHAR(50) NOT NULL,

    zone ENUM('1','2','3','4','5','6','7','8','9','10','11','12') NOT NULL,
    location VARCHAR(150) NOT NULL,
    host_name VARCHAR(100) NOT NULL,
    serial_no VARCHAR(100) NOT NULL,
    mac_address VARCHAR(17) NOT NULL,
    ip_address VARCHAR(45) DEFAULT NULL,
    domain_name VARCHAR(150) DEFAULT NULL,
    operating_system ENUM(
        'Windows 7',
        'Windows 8',
        'Windows 10',
        'Windows 11',
        'Windows Server 2012',
        'Windows Server 2016',
        'Windows Server 2019',
        'Windows Server 2022',
        'Thin OS'
    ) NOT NULL,

    ram_gb DECIMAL(10,2) NOT NULL,
    hard_disk_gb DECIMAL(10,2) NOT NULL,
    hard_disk_used_gb DECIMAL(10,2) NOT NULL,

    asset_number VARCHAR(50) NOT NULL,
    asset_type VARCHAR(100) NOT NULL,
    make VARCHAR(100) NOT NULL,
    model VARCHAR(100) NOT NULL,
    year_of_manufacture SMALLINT UNSIGNED NOT NULL,
    network_type ENUM('Intranet','Internet','Standalone') NOT NULL,
    asset_used_by ENUM('Self','Others') NOT NULL,
    warranty ENUM('Yes','No') NOT NULL,

    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_by VARCHAR(50) DEFAULT NULL,

    PRIMARY KEY (mac_address),
    UNIQUE KEY uq_asset_number (asset_number),
    UNIQUE KEY uq_serial_no (serial_no),
    KEY idx_staff_id (staff_id),
    KEY idx_cost_center (cost_center),
    KEY idx_staff_cost (staff_id, cost_center),

    CONSTRAINT chk_ram_positive CHECK (ram_gb > 0),
    CONSTRAINT chk_disk_positive CHECK (hard_disk_gb > 0),
    CONSTRAINT chk_disk_used_nonnegative CHECK (hard_disk_used_gb >= 0),
    CONSTRAINT chk_disk_used_not_more_than_disk CHECK (hard_disk_used_gb <= hard_disk_gb),
    CONSTRAINT chk_yom CHECK (year_of_manufacture BETWEEN 1980 AND 2100),
    CONSTRAINT chk_mac_length CHECK (CHAR_LENGTH(mac_address) = 17)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ============================================================
-- OPTIONAL SAMPLE ASSET
-- Delete these two lines if you want an empty report.
-- ============================================================
INSERT INTO assets
(staff_id,cost_center,zone,location,host_name,serial_no,mac_address,ip_address,domain_name,operating_system,ram_gb,hard_disk_gb,hard_disk_used_gb,asset_number,asset_type,make,model,year_of_manufacture,network_type,asset_used_by,warranty)
VALUES
('BEL001','CC1001','1','Bengaluru','BEL-PC-001','SN-DEMO-001','00:11:22:33:44:55','192.168.1.10','bel.local','Windows 11',16.00,512.00,200.00,'AST001','Desktop PC - Standard','Dell','OptiPlex',2024,'Intranet','Self','Yes');
