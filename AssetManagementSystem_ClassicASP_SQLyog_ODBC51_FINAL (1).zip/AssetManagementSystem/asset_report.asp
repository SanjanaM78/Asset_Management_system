<%@ Language="VBScript" CodePage="65001" %>
<!--#include file="includes/auth.asp"-->
<!--#include file="includes/db.asp"-->
<%
Option Explicit
Response.CodePage = 65001
Response.CharSet = "UTF-8"

Dim staffSearch, costSearch, macSearch, exportCsv
Dim cmd, rs, sql, whereSql, paramIndex
staffSearch = Trim(Request.QueryString("staff_id"))
costSearch = Trim(Request.QueryString("cost_center"))
macSearch = Trim(Request.QueryString("mac_address"))
exportCsv = (LCase(Trim(Request.QueryString("export"))) = "csv")

whereSql = " WHERE 1=1 "
If staffSearch <> "" Then whereSql = whereSql & " AND staff_id LIKE ?"
If costSearch <> "" Then whereSql = whereSql & " AND cost_center LIKE ?"
If macSearch <> "" Then whereSql = whereSql & " AND mac_address LIKE ?"

sql = "SELECT * FROM assets" & whereSql & " ORDER BY created_at DESC"
Set cmd = Server.CreateObject("ADODB.Command")
Set cmd.ActiveConnection = conn
cmd.CommandText = sql
cmd.CommandType = 1
If staffSearch <> "" Then cmd.Parameters.Append cmd.CreateParameter("p1", 200, 1, 60, "%" & staffSearch & "%")
If costSearch <> "" Then cmd.Parameters.Append cmd.CreateParameter("p2", 200, 1, 60, "%" & costSearch & "%")
If macSearch <> "" Then cmd.Parameters.Append cmd.CreateParameter("p3", 200, 1, 30, "%" & NormalizeMac(macSearch) & "%")
Set rs = cmd.Execute

If exportCsv Then
    Response.Clear
    Response.ContentType = "text/csv"
    Response.AddHeader "Content-Disposition", "attachment; filename=IT_Asset_Report.csv"
    Response.Write "Staff ID,Cost Center,Zone,Location,Host Name,Serial No,MAC Address,IP Address,Domain Name,Operating System,RAM (GB),Hard Disk (GB),Hard Disk Used (GB),Asset Number,Asset Type,Make,Model,Year of Manufacture,Type of Network,Asset Used By,Warranty,Created At" & vbCrLf
    Do Until rs.EOF
        Response.Write Csv(rs("staff_id")) & "," & Csv(rs("cost_center")) & "," & Csv(rs("zone")) & "," & Csv(rs("location")) & "," & Csv(rs("host_name")) & "," & Csv(rs("serial_no")) & "," & Csv(rs("mac_address")) & "," & Csv(rs("ip_address")) & "," & Csv(rs("domain_name")) & "," & Csv(rs("operating_system")) & "," & Csv(rs("ram_gb")) & "," & Csv(rs("hard_disk_gb")) & "," & Csv(rs("hard_disk_used_gb")) & "," & Csv(rs("asset_number")) & "," & Csv(rs("asset_type")) & "," & Csv(rs("make")) & "," & Csv(rs("model")) & "," & Csv(rs("year_of_manufacture")) & "," & Csv(rs("network_type")) & "," & Csv(rs("asset_used_by")) & "," & Csv(rs("warranty")) & "," & Csv(rs("created_at")) & vbCrLf
        rs.MoveNext
    Loop
    rs.Close : Set rs = Nothing : Set cmd = Nothing
    conn.Close : Set conn = Nothing
    Response.End
End If

Function H(v)
    If IsNull(v) Or IsEmpty(v) Then H = "" Else H = Server.HTMLEncode(CStr(v))
End Function
Function Csv(v)
    If IsNull(v) Or IsEmpty(v) Then Csv = """""" Else Csv = """" & Replace(CStr(v), """", """""") & """"
End Function
Function NormalizeMac(v)
    NormalizeMac = LCase(Replace(Replace(Trim(CStr(v & "")), "-", ":"), " ", ""))
End Function
%>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>IT Asset Report</title>
<link rel="stylesheet" href="wwwroot/css/style.css">
</head>
<body>
<header class="site-header">
    <div><h1>IT Asset Declaration</h1><p>Search and manage declared IT assets.</p></div>
    <div class="user-area"><span><%=H(Session("staffId"))%></span><a href="logout.asp">Logout</a></div>
</header>
<nav class="main-nav"><a class="active" href="asset_report.asp">Asset Report</a><a href="asset_declaration.asp">Asset Declaration</a></nav>

<main class="report-container">
<h2>Asset Report</h2>

<form method="get" action="asset_report.asp" class="report-search">
    <div><label>Staff ID</label><input type="text" name="staff_id" value="<%=H(staffSearch)%>" placeholder="Search Staff ID"></div>
    <div><label>Cost Center</label><input type="text" name="cost_center" value="<%=H(costSearch)%>" placeholder="Search Cost Center"></div>
    <div><label>MAC Address</label><input type="text" name="mac_address" value="<%=H(macSearch)%>" placeholder="Search MAC Address"></div>
    <div class="search-actions"><button class="btn primary" type="submit">Search</button><a class="btn secondary" href="asset_report.asp">Clear</a></div>
</form>

<div class="report-toolbar">
    <div>Search results</div>
    <a class="btn success" href="asset_report.asp?export=csv&amp;staff_id=<%=Server.URLEncode(staffSearch)%>&amp;cost_center=<%=Server.URLEncode(costSearch)%>&amp;mac_address=<%=Server.URLEncode(macSearch)%>">Export CSV</a>
</div>

<div class="report-table-wrap">
<table class="asset-table">
<thead>
<tr>
<th>Staff ID</th><th>Cost Center</th><th>Zone</th><th>Location</th><th>Host Name</th><th>Serial No</th><th>MAC Address</th><th>IP Address</th><th>OS</th><th>RAM</th><th>Hard Disk</th><th>Used</th><th>Asset No</th><th>Asset Type</th><th>Make</th><th>Model</th><th>YOM</th><th>Network</th><th>Used By</th><th>Warranty</th><th>Action</th>
</tr>
</thead>
<tbody>
<% If rs.EOF Then %>
<tr><td colspan="21" class="empty">No assets found.</td></tr>
<% Else %>
<% Do Until rs.EOF %>
<tr>
<td><%=H(rs("staff_id"))%></td>
<td><%=H(rs("cost_center"))%></td>
<td><%=H(rs("zone"))%></td>
<td><%=H(rs("location"))%></td>
<td><%=H(rs("host_name"))%></td>
<td><%=H(rs("serial_no"))%></td>
<td class="mac-cell"><%=H(rs("mac_address"))%></td>
<td><%=H(rs("ip_address"))%></td>
<td><%=H(rs("operating_system"))%></td>
<td><%=H(rs("ram_gb"))%></td>
<td><%=H(rs("hard_disk_gb"))%></td>
<td><%=H(rs("hard_disk_used_gb"))%></td>
<td><%=H(rs("asset_number"))%></td>
<td><%=H(rs("asset_type"))%></td>
<td><%=H(rs("make"))%></td>
<td><%=H(rs("model"))%></td>
<td><%=H(rs("year_of_manufacture"))%></td>
<td><%=H(rs("network_type"))%></td>
<td><%=H(rs("asset_used_by"))%></td>
<td><%=H(rs("warranty"))%></td>
<td class="action-cell"><a class="btn small" href="asset_edit.asp?mac=<%=Server.URLEncode(rs("mac_address"))%>">Edit</a><a class="btn small danger" href="asset_delete.asp?mac=<%=Server.URLEncode(rs("mac_address"))%>" onclick="return confirm('Delete this asset?');">Delete</a></td>
</tr>
<% rs.MoveNext : Loop %>
<% End If %>
</tbody>
</table>
</div>
</main>
</body>
</html>
<%
rs.Close : Set rs = Nothing : Set cmd = Nothing
conn.Close : Set conn = Nothing
%>
