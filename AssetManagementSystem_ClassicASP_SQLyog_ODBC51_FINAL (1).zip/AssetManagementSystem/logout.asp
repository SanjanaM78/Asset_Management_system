<%@ Language="VBScript" %>
<%
Session.Abandon
Response.Redirect "login.asp?msg=You+have+been+logged+out"
Response.End
%>
