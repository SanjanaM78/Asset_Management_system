<%@ Language="VBScript" CodePage="65001" %>
<!--#include file="includes/auth.asp"-->
<!--#include file="includes/db.asp"-->
<%
Option Explicit
Response.CodePage = 65001
Response.CharSet = "UTF-8"

Dim mac, rs, cmd, sql, message, errorMessage
Dim vStaffId, vCostCenter, vZone, vLocation, vHostName, vSerialNo, vIp, vDomain, vOS, vRam, vHardDisk, vHardDiskUsed, vAssetNumber, vAssetType, vMake, vModel, vYom, vNetwork, vAssetUsedBy, vWarranty

mac = NormalizeMac(Request.QueryString("mac"))
message = ""
errorMessage = ""

If mac = "" Then
    Response.Redirect "asset_report.asp"
    Response.End
End If

If Request.ServerVariables("REQUEST_METHOD") = "POST" Then
    mac = NormalizeMac(Request.Form("mac_address"))
    vStaffId = Trim(Request.Form("staff_id"))
    vCostCenter = Trim(Request.Form("cost_center"))
            vZone = Trim(Request.Form("zone"))
    vLocation = Trim(Request.Form("location"))
    vHostName = Trim(Request.Form("host_name"))
    vSerialNo = Trim(Request.Form("serial_no"))
    vIp = Trim(Request.Form("ip_address"))
    vDomain = Trim(Request.Form("domain_name"))
    vOS = Trim(Request.Form("operating_system"))
    vRam = Trim(Request.Form("ram"))
    vHardDisk = Trim(Request.Form("hard_disk"))
    vHardDiskUsed = Trim(Request.Form("hard_disk_used"))
    vAssetNumber = Trim(Request.Form("asset_number"))
    vAssetType = Trim(Request.Form("asset_type"))
    vMake = Trim(Request.Form("make"))
    vModel = Trim(Request.Form("model"))
    vYom = Trim(Request.Form("year_of_manufacture"))
    vNetwork = Trim(Request.Form("network_type"))
    vAssetUsedBy = Trim(Request.Form("asset_used_by"))
    vWarranty = Trim(Request.Form("warranty"))

    If vStaffId = "" Then
        errorMessage = "Staff ID is required."
    ElseIf vCostCenter = "" Then
        errorMessage = "Cost Center is required."
    ElseIf Not IsAllowedZone(vZone) Then
        errorMessage = "Please select a valid Zone from 1 to 12."
    ElseIf vLocation = "" Or vHostName = "" Or vSerialNo = "" Then
        errorMessage = "Location, Host Name and Serial No are required."
    ElseIf Not IsValidMac(mac) Then
        errorMessage = "The MAC Address is invalid."
    ElseIf Not IsAllowedOS(vOS) Then
        errorMessage = "Please select a valid Operating System."
    ElseIf vRam = "" Or Not IsNumeric(vRam) Or CDbl(vRam) <= 0 Then
        errorMessage = "RAM must be a positive number in GB."
    ElseIf vHardDisk = "" Or Not IsNumeric(vHardDisk) Or CDbl(vHardDisk) <= 0 Then
        errorMessage = "Hard Disk must be a positive number in GB."
    ElseIf vHardDiskUsed = "" Or Not IsNumeric(vHardDiskUsed) Or CDbl(vHardDiskUsed) < 0 Then
        errorMessage = "Hard Disk Used must be a valid number in GB."
    ElseIf CDbl(vHardDiskUsed) > CDbl(vHardDisk) Then
        errorMessage = "Hard Disk Used cannot be greater than Hard Disk capacity."
    ElseIf vAssetNumber = "" Then
        errorMessage = "Asset Number is required."
    ElseIf Not IsAllowedAssetType(vAssetType) Then
        errorMessage = "Please select a valid Asset Type."
    ElseIf vMake = "" Or vModel = "" Then
        errorMessage = "Make and Model are required."
    ElseIf Not IsValidYear(vYom) Then
        errorMessage = "Enter Year of Manufacture manually as a 4-digit year (for example 2024)."
    ElseIf Not IsAllowedNetwork(vNetwork) Then
        errorMessage = "Please select a valid Type of Network."
    ElseIf Not IsAllowedUsedBy(vAssetUsedBy) Then
        errorMessage = "Please select Self or Others."
    ElseIf Not IsAllowedWarranty(vWarranty) Then
        errorMessage = "Please select Warranty Yes or No."
    End If

    If errorMessage = "" Then
        sql = "SELECT asset_number FROM assets WHERE asset_number=? AND mac_address<>?"
        Set cmd = Server.CreateObject("ADODB.Command")
        Set cmd.ActiveConnection = conn
        cmd.CommandText = sql
        cmd.CommandType = 1
        cmd.Parameters.Append cmd.CreateParameter("p1", 200, 1, 50, vAssetNumber)
        cmd.Parameters.Append cmd.CreateParameter("p2", 200, 1, 17, mac)
        Set rs = cmd.Execute
        If Not rs.EOF Then errorMessage = "This Asset Number already exists."
        rs.Close : Set rs = Nothing : Set cmd = Nothing
    End If

    If errorMessage = "" Then
        sql = "SELECT serial_no FROM assets WHERE serial_no=? AND mac_address<>?"
        Set cmd = Server.CreateObject("ADODB.Command")
        Set cmd.ActiveConnection = conn
        cmd.CommandText = sql
        cmd.CommandType = 1
        cmd.Parameters.Append cmd.CreateParameter("p1", 200, 1, 100, vSerialNo)
        cmd.Parameters.Append cmd.CreateParameter("p2", 200, 1, 17, mac)
        Set rs = cmd.Execute
        If Not rs.EOF Then errorMessage = "This Serial No already exists."
        rs.Close : Set rs = Nothing : Set cmd = Nothing
    End If

    If errorMessage = "" Then
        sql = "UPDATE assets SET staff_id=?,cost_center=?,zone=?,location=?,host_name=?,serial_no=?,ip_address=?,domain_name=?,operating_system=?,ram_gb=?,hard_disk_gb=?,hard_disk_used_gb=?,asset_number=?,asset_type=?,make=?,model=?,year_of_manufacture=?,network_type=?,asset_used_by=?,warranty=?,updated_by=? WHERE mac_address=?"
        Set cmd = Server.CreateObject("ADODB.Command")
        Set cmd.ActiveConnection = conn
        cmd.CommandText = sql
        cmd.CommandType = 1
        cmd.Parameters.Append cmd.CreateParameter("p1", 200, 1, 50, vStaffId)
        cmd.Parameters.Append cmd.CreateParameter("p2", 200, 1, 50, vCostCenter)
        cmd.Parameters.Append cmd.CreateParameter("p5", 200, 1, 2, vZone)
        cmd.Parameters.Append cmd.CreateParameter("p6", 200, 1, 150, vLocation)
        cmd.Parameters.Append cmd.CreateParameter("p7", 200, 1, 100, vHostName)
        cmd.Parameters.Append cmd.CreateParameter("p8", 200, 1, 100, vSerialNo)
        cmd.Parameters.Append cmd.CreateParameter("p9", 200, 1, 45, vIp)
        cmd.Parameters.Append cmd.CreateParameter("p10", 200, 1, 150, vDomain)
        cmd.Parameters.Append cmd.CreateParameter("p11", 200, 1, 50, vOS)
        cmd.Parameters.Append cmd.CreateParameter("p12", 5, 1, 0, CDbl(vRam))
        cmd.Parameters.Append cmd.CreateParameter("p13", 5, 1, 0, CDbl(vHardDisk))
        cmd.Parameters.Append cmd.CreateParameter("p14", 5, 1, 0, CDbl(vHardDiskUsed))
        cmd.Parameters.Append cmd.CreateParameter("p15", 200, 1, 50, vAssetNumber)
        cmd.Parameters.Append cmd.CreateParameter("p16", 200, 1, 100, vAssetType)
        cmd.Parameters.Append cmd.CreateParameter("p17", 200, 1, 100, vMake)
        cmd.Parameters.Append cmd.CreateParameter("p18", 200, 1, 100, vModel)
        cmd.Parameters.Append cmd.CreateParameter("p19", 3, 1, 0, CLng(vYom))
        cmd.Parameters.Append cmd.CreateParameter("p20", 200, 1, 30, vNetwork)
        cmd.Parameters.Append cmd.CreateParameter("p21", 200, 1, 20, vAssetUsedBy)
        cmd.Parameters.Append cmd.CreateParameter("p22", 200, 1, 100, vWarranty)
        cmd.Parameters.Append cmd.CreateParameter("p23", 200, 1, 50, Session("staffId"))
        cmd.Parameters.Append cmd.CreateParameter("p24", 200, 1, 17, mac)

        On Error Resume Next
        cmd.Execute
        If Err.Number <> 0 Then
            errorMessage = "Could not update the asset: " & Err.Description
            Err.Clear
        Else
            message = "Asset updated successfully."
        End If
        On Error GoTo 0
        Set cmd = Nothing
    End If
End If

sql = "SELECT * FROM assets WHERE mac_address=?"
Set cmd = Server.CreateObject("ADODB.Command")
Set cmd.ActiveConnection = conn
cmd.CommandText = sql
cmd.CommandType = 1
cmd.Parameters.Append cmd.CreateParameter("p1", 200, 1, 17, mac)
Set rs = cmd.Execute

If rs.EOF Then
    rs.Close : Set rs = Nothing : Set cmd = Nothing
    conn.Close : Set conn = Nothing
    Response.Redirect "asset_report.asp"
    Response.End
End If

Function H(v)
    If IsNull(v) Or IsEmpty(v) Then H = "" Else H = Server.HTMLEncode(CStr(v))
End Function
Function NormalizeMac(v)
    NormalizeMac = LCase(Replace(Replace(Trim(CStr(v & "")), "-", ":"), " ", ""))
End Function
Function IsValidMac(v)
    Dim re : Set re = New RegExp
    re.Pattern = "^[0-9a-fA-F]{2}(:[0-9a-fA-F]{2}){5}$"
    IsValidMac = re.Test(v)
    Set re = Nothing
End Function
Function IsAllowedZone(v)
    IsAllowedZone = (IsNumeric(v) And CLng(v) >= 1 And CLng(v) <= 12)
End Function
Function IsAllowedOS(v)
    Dim a,i : a=Array("Windows 7","Windows 8","Windows 10","Windows 11","Windows Server 2012","Windows Server 2016","Windows Server 2019","Windows Server 2022","Thin OS")
    IsAllowedOS=False
    For i=0 To UBound(a) : If v=a(i) Then IsAllowedOS=True : Exit Function
    Next
End Function
Function IsAllowedAssetType(v)
    Dim a,i : a=Array("Desktop PC - High End","Desktop PC - Standard","Laptop - High End","Laptop - Standard","Laptop - Medium","Workstation - High","Workstation - Standard","Workstation - Medium","Printer","Scanner","Server","Other")
    IsAllowedAssetType=False
    For i=0 To UBound(a) : If v=a(i) Then IsAllowedAssetType=True : Exit Function
    Next
End Function
Function IsValidYear(v)
    Dim i, ch
    v = Trim(CStr(v & ""))
    If Len(v) <> 4 Then
        IsValidYear = False
        Exit Function
    End If
    For i = 1 To Len(v)
        ch = Mid(v, i, 1)
        If ch < "0" Or ch > "9" Then
            IsValidYear = False
            Exit Function
        End If
    Next
    IsValidYear = (CLng(v) >= 1900 And CLng(v) <= 2100)
End Function

Function IsAllowedNetwork(v)
    IsAllowedNetwork=(v="Intranet" Or v="Internet" Or v="Standalone")
End Function
Function IsAllowedUsedBy(v)
    IsAllowedUsedBy=(v="Self" Or v="Others")
End Function
%>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Edit Asset</title>
<link rel="stylesheet" href="wwwroot/css/style.css">
<script src="wwwroot/js/script.js" defer></script>
</head>
<body>
<header class="site-header">
    <div><h1>IT Asset Declaration</h1><p>Edit selected asset information.</p></div>
    <div class="user-area"><span><%=H(Session("staffId"))%></span><a href="logout.asp">Logout</a></div>
</header>
<nav class="main-nav"><a href="asset_report.asp">Asset Report</a><a href="asset_declaration.asp">Asset Declaration</a></nav>
<main class="page-container">
<% If message<>"" Then %><div class="alert success"><%=H(message)%></div><% End If %>
<% If errorMessage<>"" Then %><div class="alert error"><%=H(errorMessage)%></div><% End If %>
<form method="post" action="asset_edit.asp?mac=<%=Server.URLEncode(mac)%>" id="assetForm" onsubmit="return validateAssetForm();">

<section class="asset-section">
<div class="section-heading">Staff Information</div>
<div class="section-grid three-col">
<div class="field"><label>Staff ID <span>*</span></label><input type="text" name="staff_id" value="<%=H(rs("staff_id"))%>" readonly></div>
<div class="field"><label>Cost Center <span>*</span></label><input type="text" name="cost_center" value="<%=H(rs("cost_center"))%>" maxlength="50" required></div>
</div>
</section>

<section class="asset-section">
<div class="section-heading">1. Location &amp; System Information</div>
<div class="section-grid three-col">
<div class="field"><label>Zone <span>*</span></label><select name="zone" required><option value="">Select Zone</option><% Dim z : For z=1 To 12 %><option value="<%=z%>" <% If CStr(rs("zone"))=CStr(z) Then Response.Write "selected" %>><%=z%></option><% Next %></select></div>
<div class="field"><label>Location <span>*</span></label><input type="text" name="location" value="<%=H(rs("location"))%>" maxlength="150" required></div>
<div class="field"><label>Host Name <span>*</span></label><input type="text" name="host_name" value="<%=H(rs("host_name"))%>" maxlength="100" required></div>
<div class="field"><label>Serial No <span>*</span></label><input type="text" name="serial_no" value="<%=H(rs("serial_no"))%>" maxlength="100" required></div>
<div class="field"><label>MAC Address <span>*</span></label><input type="text" name="mac_address" value="<%=H(rs("mac_address"))%>" readonly><div class="field-note">MAC Address is the PRIMARY KEY and cannot be changed.</div></div>
<div class="field"><label>IP Address</label><input type="text" name="ip_address" value="<%=H(rs("ip_address"))%>" maxlength="45"></div>
<div class="field"><label>Domain Name</label><input type="text" name="domain_name" value="<%=H(rs("domain_name"))%>" maxlength="150"></div>
<div class="field"><label>Operating System <span>*</span></label><select name="operating_system" required><option value="">Select OS</option><option <% If CStr(rs("operating_system"))="Windows 7" Then Response.Write "selected" %>>Windows 7</option><option <% If CStr(rs("operating_system"))="Windows 8" Then Response.Write "selected" %>>Windows 8</option><option <% If CStr(rs("operating_system"))="Windows 10" Then Response.Write "selected" %>>Windows 10</option><option <% If CStr(rs("operating_system"))="Windows 11" Then Response.Write "selected" %>>Windows 11</option><option <% If CStr(rs("operating_system"))="Windows Server 2012" Then Response.Write "selected" %>>Windows Server 2012</option><option <% If CStr(rs("operating_system"))="Windows Server 2016" Then Response.Write "selected" %>>Windows Server 2016</option><option <% If CStr(rs("operating_system"))="Windows Server 2019" Then Response.Write "selected" %>>Windows Server 2019</option><option <% If CStr(rs("operating_system"))="Windows Server 2022" Then Response.Write "selected" %>>Windows Server 2022</option><option <% If CStr(rs("operating_system"))="Thin OS" Then Response.Write "selected" %>>Thin OS</option></select></div>
<div class="field"><label>RAM (GB) <span>*</span></label><input type="number" name="ram" value="<%=H(rs("ram_gb"))%>" min="0.01" step="0.01" required></div>
<div class="field"><label>Hard Disk (GB) <span>*</span></label><input type="number" name="hard_disk" value="<%=H(rs("hard_disk_gb"))%>" min="0.01" step="0.01" required></div>
<div class="field"><label>Hard Disk Used (GB) <span>*</span></label><input type="number" name="hard_disk_used" value="<%=H(rs("hard_disk_used_gb"))%>" min="0" step="0.01" required></div>
</div>
</section>

<section class="asset-section">
<div class="section-heading">2. Asset Details</div>
<div class="section-grid three-col">
<div class="field"><label>Asset Number <span>*</span></label><input type="text" name="asset_number" value="<%=H(rs("asset_number"))%>" maxlength="50" required></div>
<div class="field asset-type-field"><label>Asset Type <span>*</span></label><select name="asset_type" id="asset_type" required><option value="">Select Asset Type</option><option value="Desktop PC - High End">Desktop PC - High End</option><option value="Desktop PC - Standard">Desktop PC - Standard</option><option value="Laptop - High End">Laptop - High End</option><option value="Laptop - Standard">Laptop - Standard</option><option value="Laptop - Medium">Laptop - Medium</option><option value="Workstation - High">Workstation - High</option><option value="Workstation - Standard">Workstation - Standard</option><option value="Workstation - Medium">Workstation - Medium</option><option value="Printer">Printer</option><option value="Scanner">Scanner</option><option value="Server">Server</option><option value="Other">Other</option></select></div>
<div class="field"><label>Make <span>*</span></label><input type="text" name="make" value="<%=H(rs("make"))%>" maxlength="100" required></div>
<div class="field"><label>Model <span>*</span></label><input type="text" name="model" value="<%=H(rs("model"))%>" maxlength="100" required></div>
<div class="field"><label>Year of Manufacture <span>*</span></label><input type="text" name="year_of_manufacture" value="<%=H(vYom)%>" maxlength="4" inputmode="numeric" pattern="[0-9]{4}" placeholder="YYYY" required></div>
<div class="field"><label>Type of Network <span>*</span></label><select name="network_type" required><option value="">Select</option><option <% If CStr(rs("network_type"))="Intranet" Then Response.Write "selected" %>>Intranet</option><option <% If CStr(rs("network_type"))="Internet" Then Response.Write "selected" %>>Internet</option><option <% If CStr(rs("network_type"))="Standalone" Then Response.Write "selected" %>>Standalone</option></select></div>
<div class="field"><label>Asset Used By <span>*</span></label><select name="asset_used_by" required><option value="">Select</option><option <% If CStr(rs("asset_used_by"))="Self" Then Response.Write "selected" %>>Self</option><option <% If CStr(rs("asset_used_by"))="Others" Then Response.Write "selected" %>>Others</option></select></div>
<div class="field"><label>Warranty <span>*</span></label><select name="warranty" required><option value="">Select</option><option <% If CStr(rs("warranty"))="Yes" Then Response.Write "selected" %>>Yes</option><option <% If CStr(rs("warranty"))="No" Then Response.Write "selected" %>>No</option></select></div>
</div>
</section>

<div class="form-actions"><button type="submit" class="btn primary">Update Asset</button><a href="asset_report.asp" class="btn secondary">Cancel</a></div>
</form>
</main>
</body>
</html>
<%
rs.Close : Set rs = Nothing : Set cmd = Nothing
conn.Close : Set conn = Nothing
%>
